/**
 * ============================================================================
 *  LUBRAX · RENDER DE PRUEBA (MOCK) — ELIMINABLE
 * ============================================================================
 *  Simula lo que hará el CMS en el servidor: toma los datos de mock-data.js,
 *  rellena las plantillas <template id="tpl-…"> de cada página y las inserta
 *  en los contenedores marcados con data-mock="…".
 *
 *  Se ejecuta ANTES de app.js (todos los scripts usan defer y respetan el orden),
 *  así el JavaScript de producción encuentra el marcado igual que si viniera
 *  del servidor.
 *
 *  Sintaxis de las plantillas:
 *    {{campo}}    texto escapado
 *    {{{campo}}}  HTML sin escapar (solo para fragmentos generados aquí)
 *
 *  Para pasar a producción: borrar assets/mock/ y los <script> marcados "MOCK".
 * ============================================================================
 */
(() => {
  'use strict';

  const M = window.LBX_MOCK;
  if (!M) return;

  /* ---------------------------------------------------------------- utilidades */
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const get = (obj, path) => path.split('.').reduce((acc, k) => (acc == null ? acc : acc[k]), obj);
  const cache = {};
  const tpl = (id) => (cache[id] ??= (document.getElementById(id)?.innerHTML || ''));
  const fill = (id, data) => tpl(id).replace(/\{\{\{\s*([\w.]+)\s*\}\}\}|\{\{\s*([\w.]+)\s*\}\}/g,
    (_, raw, key) => (raw ? String(get(data, raw) ?? '') : esc(get(data, key))));
  /* Las tablas no admiten texto suelto dentro de <template>: sus filas se cargan en
     un "slot" (<tbody data-slot="campo">) después de insertar la plantilla. */
  const mount = (name, html, slots = {}) => $$(`[data-mock="${name}"]`).forEach((el) => {
    el.insertAdjacentHTML('beforeend', html);
    $$('[data-slot]', el).forEach((slot) => { if (slot.dataset.slot in slots) { slot.innerHTML = slots[slot.dataset.slot]; slot.removeAttribute('data-slot'); } });
  });
  const has = (name) => !!$(`[data-mock="${name}"]`);
  const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
  const tel = (phone) => String(phone).replace(/[^\d+]/g, '');
  const addJsonLd = (data) => {
    const s = document.createElement('script');
    s.type = 'application/ld+json';
    s.textContent = JSON.stringify(data);
    document.head.append(s);
  };

  const catById = Object.fromEntries(M.categories.map((c) => [c.id, c]));
  const prodById = Object.fromEntries(M.products.map((p) => [p.id, p]));
  const distById = Object.fromEntries(M.distributors.map((d) => [d.id, d]));
  const countByCat = M.products.reduce((acc, p) => { acc[p.category] = (acc[p.category] || 0) + 1; return acc; }, {});

  /* Imagen de cada presentación (en el CMS: campo imagen de la variante) */
  const PRES_IMG = {
    '1 L': 'botella-1l', '4 L': 'bidon-4l', '20 L': 'balde-20l', 'Cubeta 19 L': 'balde-20l',
    'Tambo 200 L': 'tambor-200l', 'Granel 1000 L': 'ibc-1000l'
  };
  const presImage = (label) => `assets/mock/img/presentaciones/${PRES_IMG[label] || 'tambor-200l'}.webp`;

  /* Datos de una tarjeta de producto */
  const cardData = (p) => ({
    ...p,
    categoryName: catById[p.category]?.name || '',
    tagLabel: (catById[p.category]?.name || '') + (p.fuel ? ` · ${p.fuel}` : ''),
    featured: p.featured ? '1' : '0',
    specsPipe: p.specs.join('|'),
    distributorsSpace: p.distributors.join(' '),
    specBadges: p.specs.map((s) => `<span class="badge-spec">${esc(s)}</span>`).join('')
  });

  /* ------------------------------------------------- 1. Selector de distribuidor */
  const distSelect = document.getElementById('distributorSelect');
  if (distSelect) {
    M.distributors.forEach((d) => {
      const o = new Option(d.name, d.id);
      Object.assign(o.dataset, { label: d.label, region: d.region, lat: d.lat, lng: d.lng });
      distSelect.add(o);
    });
  }

  /* --------------------------------------------------- 2. Home: categorías */
  if (has('categories')) {
    mount('categories', M.categories.map((c) => fill('tpl-category', { ...c, count: plural(countByCat[c.id] || 0, 'producto', 'productos') })).join(''));
  }
  $$('select[data-mock="category-options"]').forEach((sel) => M.categories.forEach((c) => sel.add(new Option(c.name, c.id))));
  /* Selectores de producto agrupados por categoría (<optgroup>). data-url = ficha del producto */
  $$('select[data-mock="product-options"]').forEach((sel) => M.categories.forEach((c) => {
    const items = M.products.filter((p) => p.category === c.id);
    if (!items.length) return;
    const group = document.createElement('optgroup');
    group.label = c.name;
    items.forEach((p) => { const o = new Option(p.name, p.id); o.dataset.url = `producto.html?id=${p.id}`; group.append(o); });
    sel.append(group);
  }));

  /* Isla JSON del buscador del home (en el CMS: impresa con json_encode / wp_json_encode) */
  $$('[data-mock="product-index"]').forEach((el) => { el.textContent = JSON.stringify(M.products.map((p) => ({ id: p.id, category: p.category, sae: p.sae }))); });

  /* ------------------------------------------------------- 3. Catálogo */
  if (has('catalog-categories')) {
    mount('catalog-categories', M.categories.map((c) => fill('tpl-cat-link', { ...c, count: countByCat[c.id] || 0 })).join(''));
  }
  if (has('product-cards')) {
    mount('product-cards', M.products.map((p) => fill('tpl-product-card', cardData(p))).join(''));
  }

  /* ------------------------------------------------ 4. Detalle de producto */
  if (has('product-page')) {
    const wanted = new URLSearchParams(window.location.search).get('id');
    const p = prodById[wanted] || M.products[0];
    const cat = catById[p.category];
    const presImgs = [...new Set(p.presentations.map(presImage))];
    const gallery = [{ src: p.image, alt: p.name }, ...presImgs.map((src) => ({ src, alt: `${p.name}, envase ${p.presentations.find((l) => presImage(l) === src)}` }))];
    const dists = p.distributors.map((id) => distById[id]).filter(Boolean);

    const propertyRows = p.properties.map(([k, v]) => `<tr><th scope="row">${esc(k)}</th><td>${esc(v)}</td></tr>`).join('');
    mount('product-page', fill('tpl-product-page', {
      ...cardData(p),
      categoryName: cat?.name || '',
      fuelLabel: p.fuel ? ` · ${p.fuel}` : '',
      specsLabel: p.specs.join(' / '),
      thumbs: gallery.map((g, i) => `<button type="button" data-gallery-src="${esc(g.src)}" data-gallery-alt="${esc(g.alt)}" aria-pressed="${i === 0}" aria-label="Ver imagen: ${esc(g.alt)}"><img src="${esc(g.src)}" alt="" width="80" height="80" loading="lazy" decoding="async"></button>`).join(''),
      presButtons: p.presentations.map((l) => `<button type="button" class="pres-chip" data-pres="${esc(l)}" data-pres-image="${esc(presImage(l))}" data-pres-alt="${esc(`${p.name}, envase ${l}`)}" aria-pressed="false">${esc(l)}</button>`).join(''),
      applicationItems: p.applications.map((a) => `<li data-reveal="up">${esc(a)}</li>`).join(''),
      docs: p.documents.map((d) => fill('tpl-doc-card', { ...d, product: p.name })).join(''),
      distCount: plural(dists.length, 'distribuidor', 'distribuidores'),
      miniDists: dists.length
        ? dists.map((d) => fill('tpl-mini-dist', { ...d, phoneTel: tel(d.phone) })).join('')
        : '<li class="col-12"><p class="mb-0">Este producto se vende por pedido. <a href="contacto.html?tipo=pedido#formulario">Consúltanos</a>.</p></li>'
    }), { propertyRows });

    document.title = `${p.name} | Lubrax`;
    $('meta[name="description"]')?.setAttribute('content', `${p.name} (${p.sae}, ${p.base.toLowerCase()}): ${p.short}`);
    $('meta[property="og:title"]')?.setAttribute('content', `${p.name} | Lubrax`);
    const site = $('link[rel="canonical"]')?.href.replace(/producto\.html.*$/, '') || '';
    addJsonLd({
      '@context': 'https://schema.org',
      '@graph': [
        {
          '@type': 'Product', name: p.name, sku: p.id, description: p.description, category: cat?.name,
          image: site + p.image, brand: { '@type': 'Brand', name: 'Lubrax' },
          additionalProperty: [['Viscosidad SAE', p.sae], ['Tipo de base', p.base], ...p.properties]
            .map(([name, value]) => ({ '@type': 'PropertyValue', name, value }))
        },
        {
          '@type': 'BreadcrumbList',
          itemListElement: [
            { '@type': 'ListItem', position: 1, name: 'Inicio', item: site },
            { '@type': 'ListItem', position: 2, name: 'Productos', item: `${site}productos.html` },
            { '@type': 'ListItem', position: 3, name: cat?.name, item: `${site}productos.html?categoria=${p.category}` },
            { '@type': 'ListItem', position: 4, name: p.name }
          ]
        }
      ]
    });
  }

  /* -------------------------------------------------------- 5. Distribuidores */
  if (has('distributor-cards')) {
    mount('distributor-cards', M.distributors.map((d) => fill('tpl-dist-card', {
      ...d,
      phoneTel: tel(d.phone),
      packsLabel: d.packs.join(' · '),
      productsSpace: d.products.join(' '),
      route: `https://www.google.com/maps/dir/?api=1&destination=${d.lat},${d.lng}`
    })).join(''));
  }

  /* ----------------------------------------------------------- 5b. Blog */
  const MONTHS = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sept', 'oct', 'nov', 'dic'];
  const dateLabel = (iso) => { const [y, m, d] = iso.split('-').map(Number); return `${d} ${MONTHS[m - 1]} ${y}`; };
  const postCatById = Object.fromEntries((M.postCategories || []).map((c) => [c.id, c]));
  const postData = (p) => ({ ...p, categoryName: postCatById[p.category]?.name || '', tagsSpace: p.tags.join(' '), dateLabel: dateLabel(p.date) });
  if (has('posts')) mount('posts', M.posts.map((p) => fill('tpl-post-card', postData(p))).join(''));
  if (has('popular-posts')) {
    mount('popular-posts', M.posts.filter((p) => p.popular).slice(0, 4)
      .map((p, i) => fill('tpl-popular', { ...postData(p), num: String(i + 1).padStart(2, '0') })).join(''));
  }
  if (has('post-tags')) mount('post-tags', M.postTags.map((t) => fill('tpl-post-tag', t)).join(''));

  /* ---------------------------------------------- 6. Preguntas frecuentes */
  const renderFaqs = (name, list, { open = false, schema = false } = {}) => {
    $$(`[data-mock="${name}"]`).forEach((box) => {
      const parent = box.id || `faq-${name}`;
      box.id = parent;
      box.insertAdjacentHTML('beforeend', list.map((f, i) => fill('tpl-faq', {
        ...f, uid: `${parent}-${i + 1}`, parent,
        btnClass: open && i === 0 ? '' : ' collapsed',
        expanded: String(open && i === 0),
        show: open && i === 0 ? ' show' : ''
      })).join(''));
    });
    if (schema && has(name)) {
      addJsonLd({
        '@context': 'https://schema.org', '@type': 'FAQPage',
        mainEntity: list.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } }))
      });
    }
  };
  renderFaqs('faqs', M.faqs, { open: true, schema: true });
  renderFaqs('attention-faqs', M.attentionFaqs);

  /* --------------------------------------------- 7. Envío de formularios (demo) */
  /* app.js emite 'lbx:formsubmit' cuando el formulario es válido. Aquí se cancela
     el envío real y se muestra el mensaje de éxito que ya trae el marcado. */
  document.addEventListener('lbx:formsubmit', (e) => {
    e.preventDefault();
    const form = e.detail.form;
    const box = form.parentElement.querySelector('[data-form-success]');
    if (box) {
      form.hidden = true;
      box.hidden = false;
      box.focus();
    } else if (window.LBX?.toast) {
      LBX.toast(form.classList.contains('newsletter') ? '¡Listo! Te suscribiste al newsletter (demo).' : 'Mensaje enviado (demo).');
    }
    form.reset();
    form.classList.remove('was-validated');
    form.querySelector('#contactType')?.dispatchEvent(new Event('change'));
  });
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-form-reset]');
    if (!btn) return;
    const box = btn.closest('[data-form-success]');
    const form = box?.parentElement.querySelector('form');
    if (!form) return;
    box.hidden = true;
    form.hidden = false;
    form.querySelector('select, input')?.focus();
  });

  /* Aviso en consola para el equipo de desarrollo */
  console.info('%cLubrax · contenido de prueba (assets/mock). Quitar al conectar el CMS.', 'color:#004415;font-weight:bold');
})();
