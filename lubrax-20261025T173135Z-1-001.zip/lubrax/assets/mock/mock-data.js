/**
 * ============================================================================
 *  LUBRAX · DATOS DE PRUEBA (MOCK) — ELIMINABLE
 * ============================================================================
 *  Este archivo y mock-render.js simulan el contenido que entregará el CMS
 *  (WordPress o CMS propio). Para pasar a producción:
 *    1. Borrar la carpeta assets/mock/ completa.
 *    2. Quitar en cada página los <script> marcados con "MOCK".
 *    3. Renderizar desde el CMS el mismo marcado de los <template id="tpl-…">.
 *
 *  Los nombres de campos están pensados para mapear 1:1 a tipos de contenido:
 *    - producto      → products[]      (post type)
 *    - categoría     → categories[]    (taxonomía)
 *    - distribuidor  → distributors[]  (post type)
 *    - pregunta      → faqs[]          (post type o repetidor)
 *    - artículo      → posts[]         (entradas del blog; postCategories / postTags = taxonomías)
 *
 *  TODO el contenido es de ejemplo (viene del wireframe del cliente):
 *  nombres de distribuidores, direcciones, teléfonos y valores técnicos.
 * ============================================================================
 */
(function () {
  'use strict';

  var DOCS = {
    ficha: { type: 'Ficha técnica', file: 'assets/mock/docs/ficha-tecnica-ejemplo.pdf', thumb: 'assets/mock/docs/ficha-tecnica-ejemplo.webp', size: '216 KB', updated: 'Septiembre 2026' },
    sds: { type: 'Hoja de seguridad (SDS)', file: 'assets/mock/docs/hoja-seguridad-ejemplo.pdf', thumb: 'assets/mock/docs/hoja-seguridad-ejemplo.webp', size: '107 KB', updated: 'Agosto 2026' }
  };

  var categories = [
    { id: 'automotriz', name: 'Automotriz', icon: 'assets/img/categories/auto.svg', description: 'Motores de pasajeros, SUV, pick-ups y carga. Elige gasolina o diésel.' },
    { id: 'motocicletas', name: 'Motocicletas', icon: 'assets/img/categories/moto.svg', description: 'Motores de 2 y 4 tiempos, uso urbano y de reparto.' },
    { id: 'transmisiones', name: 'Transmisiones y engranajes', icon: 'assets/img/categories/transmisiones.svg', description: 'Cajas manuales, automáticas, diferenciales y reductores.' },
    { id: 'ferroviario', name: 'Ferroviario', icon: 'assets/img/categories/ferroviario.svg', description: 'Motores diésel de locomotora, transmisiones y equipo de vía.' },
    { id: 'maritimo', name: 'Marítimo', icon: 'assets/img/categories/maritimo.svg', description: 'Motores marinos de cuatro tiempos, sistemas de cubierta y engranajes.' },
    { id: 'industrial', name: 'Industrial', icon: 'assets/img/categories/industrial.svg', description: 'Hidráulicos, compresores, turbinas y fluidos de proceso.' },
    { id: 'agricola', name: 'Agrícola', icon: 'assets/img/categories/agricola.svg', description: 'Tractores, cosechadoras y equipo de labranza, aceites multiuso.' },
    { id: 'linea-pesada', name: 'Línea pesada', icon: 'assets/img/categories/linea-pesada.svg', description: 'Camión de carga, maquinaria pesada y equipo fuera de carretera en servicio continuo.' }
  ];

  /* p(): atajo para declarar productos sin repetir los documentos */
  function p(o) {
    o.image = 'assets/mock/img/productos/' + o.id + '.webp';
    o.documents = [DOCS.ficha, DOCS.sds];
    return o;
  }

  var products = [
    p({ id: 'valora-5w-30', name: 'Lubrax Valora 5W-30', category: 'automotriz', fuel: 'Gasolina', sae: '5W-30', specs: ['API SP', 'ILSAC GF-6A'], base: 'Sintético', featured: true,
      short: 'Sintético de alto desempeño para motores modernos con turbo e inyección directa.',
      description: 'Aceite 100% sintético formulado para motores a gasolina de última generación. Protege contra depósitos en inyección directa, reduce el consumo de combustible y mantiene la limpieza del motor en intervalos extendidos.',
      presentations: ['1 L', '4 L', '20 L', 'Tambo 200 L'],
      applications: ['Automóviles y SUV a gasolina con turbo o inyección directa', 'Vehículos que requieren API SP / ILSAC GF-6A', 'Flotas urbanas de reparto ligero', 'Servicio severo con arranques y paradas frecuentes'],
      properties: [['Índice de viscosidad', '168'], ['Viscosidad a 100 °C', '10,9 mm²/s'], ['Punto de inflamación', '228 °C'], ['Punto de fluidez', '-39 °C'], ['Intervalo de cambio sugerido', 'Hasta 10.000 km']] }),
    p({ id: 'essencial-20w-50', name: 'Lubrax Essencial 20W-50', category: 'automotriz', fuel: 'Gasolina', sae: '20W-50', specs: ['API SL'], base: 'Mineral',
      short: 'Mineral multigrado para motores de alto kilometraje y clima cálido.',
      description: 'Aceite mineral multigrado para motores a gasolina de generaciones anteriores y alto kilometraje. Buen control de consumo de aceite y protección contra desgaste en condiciones de temperatura elevada.',
      presentations: ['1 L', '4 L', '20 L', 'Tambo 200 L'],
      applications: ['Motores a gasolina de alto kilometraje', 'Taxis y transporte urbano de pasajeros', 'Clima cálido y tráfico denso', 'Talleres con servicio de cambio rápido'],
      properties: [['Índice de viscosidad', '122'], ['Viscosidad a 100 °C', '18,2 mm²/s'], ['Punto de inflamación', '236 °C'], ['Punto de fluidez', '-24 °C'], ['Intervalo de cambio sugerido', 'Hasta 5.000 km']] }),
    p({ id: 'top-turbo-15w-40', name: 'Lubrax Top Turbo 15W-40', category: 'automotriz', fuel: 'Diésel', sae: '15W-40', specs: ['API CK-4'], base: 'Semisintético', featured: true,
      short: 'Diésel de servicio severo para flotas de carga con postratamiento.',
      description: 'Aceite para motores diésel de servicio severo, compatible con sistemas de postratamiento de gases (DPF, SCR). Controla el hollín, resiste la oxidación y protege el tren de válvulas en operación continua.',
      presentations: ['20 L', 'Cubeta 19 L', 'Tambo 200 L', 'Granel 1000 L'],
      applications: ['Tractocamiones y transporte de carga de larga distancia', 'Autobuses urbanos e interurbanos', 'Motores Euro V y Euro VI con DPF/SCR', 'Flotas con programa de análisis de aceite usado'],
      properties: [['Índice de viscosidad', '142'], ['Viscosidad a 100 °C', '14,6 mm²/s'], ['TBN', '10,1 mg KOH/g'], ['Ceniza sulfatada', '0,9 %'], ['Intervalo de cambio sugerido', 'Según análisis, hasta 45.000 km']] }),
    p({ id: 'extra-diesel-15w-40', name: 'Lubrax Extra Diesel 15W-40', category: 'automotriz', fuel: 'Diésel', sae: '15W-40', specs: ['API CI-4'], base: 'Mineral',
      short: 'Diésel mixto para flota y maquinaria sin postratamiento.',
      description: 'Aceite multigrado para motores diésel con y sin turbo, indicado para flotas mixtas y maquinaria de construcción sin sistema de postratamiento. Amplia compatibilidad y disponibilidad en presentaciones mayoristas.',
      presentations: ['20 L', 'Tambo 200 L', 'Granel 1000 L'],
      applications: ['Flotas mixtas de carga y pasaje', 'Maquinaria de construcción y movimiento de tierra', 'Generadores diésel estacionarios', 'Motores sin DPF'],
      properties: [['Índice de viscosidad', '138'], ['Viscosidad a 100 °C', '14,3 mm²/s'], ['TBN', '9,6 mg KOH/g'], ['Punto de inflamación', '232 °C'], ['Intervalo de cambio sugerido', 'Hasta 20.000 km']] }),
    p({ id: 'motomax-10w-30', name: 'Lubrax Motomax 10W-30', category: 'motocicletas', sae: '10W-30', specs: ['API SN', 'JASO MA2'], base: 'Semisintético', featured: true,
      short: 'Cuatro tiempos con embrague húmedo, uso urbano y de reparto.',
      description: 'Aceite para motocicletas de cuatro tiempos con embrague húmedo. Mantiene el coeficiente de fricción requerido por JASO MA2 y protege la transmisión integrada en uso intensivo de ciudad.',
      presentations: ['1 L', '4 L', '20 L'],
      applications: ['Motocicletas 4T de 125 a 500 cc', 'Flotas de reparto y mensajería', 'Motos con embrague húmedo y caja integrada', 'Tráfico urbano con ralentí prolongado'],
      properties: [['Índice de viscosidad', '152'], ['Viscosidad a 100 °C', '10,2 mm²/s'], ['Punto de inflamación', '224 °C'], ['Especificación JASO', 'MA2'], ['Intervalo de cambio sugerido', 'Hasta 6.000 km']] }),
    p({ id: 'gear-85w-140', name: 'Lubrax Gear 85W-140', category: 'transmisiones', sae: '85W-140', specs: ['API GL-5'], base: 'Mineral',
      short: 'Diferenciales y ejes de alta carga con extrema presión.',
      description: 'Aceite para engranajes hipoidales con aditivación de extrema presión. Indicado para diferenciales y ejes de vehículos de carga y maquinaria sometidos a cargas de choque.',
      presentations: ['20 L', 'Tambo 200 L'],
      applications: ['Diferenciales y ejes traseros de carga pesada', 'Reductores industriales de engranaje recto', 'Maquinaria agrícola de alta carga', 'Servicio con cargas de choque'],
      properties: [['Índice de viscosidad', '98'], ['Viscosidad a 100 °C', '31,5 mm²/s'], ['Punto de inflamación', '218 °C'], ['Prueba Timken OK Load', '60 lb'], ['Intervalo de cambio sugerido', 'Hasta 100.000 km']] }),
    p({ id: 'atf-multi', name: 'Lubrax ATF Multi', category: 'transmisiones', sae: 'Multivehículo', specs: ['Dexron VI'], base: 'Sintético',
      short: 'Transmisión automática multivehículo, cambios suaves en frío.',
      description: 'Fluido sintético para transmisiones automáticas de múltiples fabricantes. Estabilidad térmica alta y fricción controlada para cambios suaves en frío y en operación sostenida.',
      presentations: ['1 L', '4 L', '20 L'],
      applications: ['Transmisiones automáticas de pasajeros y SUV', 'Autobuses con transmisión automática', 'Sistemas de dirección hidráulica compatibles', 'Servicio de taller multimarca'],
      properties: [['Índice de viscosidad', '175'], ['Viscosidad a 100 °C', '6,1 mm²/s'], ['Punto de fluidez', '-45 °C'], ['Color', 'Rojo'], ['Intervalo de cambio sugerido', 'Según fabricante']] }),
    p({ id: 'ferro-loco-40', name: 'Lubrax Ferro Loco 40', category: 'ferroviario', sae: 'SAE 40', specs: ['API CF', 'Generación 5'], base: 'Mineral',
      short: 'Motor diésel de locomotora en servicio continuo.',
      description: 'Aceite de alta alcalinidad para motores diésel de locomotora de dos y cuatro tiempos, con control de depósitos en pistón y protección de cojinetes plateados bajo carga sostenida.',
      presentations: ['Tambo 200 L', 'Granel 1000 L'],
      applications: ['Locomotoras de carga y pasajeros', 'Motores EMD y GE', 'Grupos electrógenos estacionarios', 'Equipo de maniobra en patio'],
      properties: [['Índice de viscosidad', '99'], ['Viscosidad a 100 °C', '13,8 mm²/s'], ['TBN', '13,0 mg KOH/g'], ['Compatibilidad con plata', 'Aprobado'], ['Intervalo de cambio sugerido', 'Según análisis de aceite']] }),
    p({ id: 'ferro-gear-220', name: 'Lubrax Ferro Gear 220', category: 'ferroviario', sae: 'ISO VG 220', specs: ['DIN 51517-3 CLP'], base: 'Mineral',
      short: 'Reductores y transmisiones de equipo de vía.',
      description: 'Aceite de engranajes industriales para transmisiones finales, reductores de tracción y maquinaria de mantenimiento de vía expuesta a golpe de carga y vibración.',
      presentations: ['Cubeta 19 L', 'Tambo 200 L'],
      applications: ['Reductores de tracción', 'Maquinaria de mantenimiento de vía', 'Cajas de engranajes de alta carga', 'Equipo de patio ferroviario'],
      properties: [['Índice de viscosidad', '97'], ['Viscosidad a 40 °C', '220 mm²/s'], ['Prueba FZG', 'Etapa 12'], ['Punto de escurrimiento', '-18 °C'], ['Intervalo de cambio sugerido', '8.000 h o según análisis']] }),
    p({ id: 'marine-tp-40', name: 'Lubrax Marine TP 40', category: 'maritimo', sae: 'SAE 40', specs: ['API CF', 'TBN 40'], base: 'Mineral',
      short: 'Motor marino de cuatro tiempos con combustible pesado.',
      description: 'Aceite de cárter para motores marinos medianos de cuatro tiempos que operan con combustible residual. Alta reserva alcalina para neutralizar azufre y mantener limpias las camisas.',
      presentations: ['Tambo 200 L', 'Granel 1000 L'],
      applications: ['Motores principales de cuatro tiempos', 'Generadores de a bordo', 'Embarcaciones de carga y pesca', 'Remolcadores portuarios'],
      properties: [['Índice de viscosidad', '95'], ['Viscosidad a 100 °C', '14,0 mm²/s'], ['TBN', '40 mg KOH/g'], ['Punto de inflamación', '240 °C'], ['Intervalo de cambio sugerido', 'Según análisis de aceite']] }),
    p({ id: 'marine-deck-68', name: 'Lubrax Marine Deck 68', category: 'maritimo', sae: 'ISO VG 68', specs: ['DIN 51524-2 HLP'], base: 'Mineral',
      short: 'Sistemas hidráulicos de cubierta y maniobra.',
      description: 'Fluido hidráulico con protección reforzada contra herrumbre y buena separación de agua salada, para grúas de cubierta, winches y timón.',
      presentations: ['Cubeta 19 L', 'Tambo 200 L'],
      applications: ['Grúas y winches de cubierta', 'Sistemas de timón', 'Maquinaria de amarre', 'Portones y rampas hidráulicas'],
      properties: [['Índice de viscosidad', '102'], ['Viscosidad a 40 °C', '68 mm²/s'], ['Prueba de herrumbre', 'Aprobado agua de mar'], ['Demulsibilidad', '40/37/3 en 15 min'], ['Intervalo de cambio sugerido', '4.000 h o según análisis']] }),
    p({ id: 'hidraulico-hv-68', name: 'Lubrax Hidráulico HV 68', category: 'industrial', sae: 'ISO VG 68', specs: ['HV', 'HLP'], base: 'Mineral',
      short: 'Hidráulico de alto índice de viscosidad para sistemas exigentes.',
      description: 'Aceite hidráulico antidesgaste de alto índice de viscosidad para sistemas de presión elevada con variaciones de temperatura. Buena filtrabilidad y separación de agua.',
      presentations: ['20 L', 'Tambo 200 L', 'Granel 1000 L'],
      applications: ['Prensas y sistemas hidráulicos industriales', 'Equipo móvil con bomba de pistón', 'Maquinaria expuesta a variación térmica', 'Sistemas con filtración fina'],
      properties: [['Índice de viscosidad', '158'], ['Viscosidad a 40 °C', '68 mm²/s'], ['Punto de inflamación', '240 °C'], ['Prueba FZG', 'Etapa 11'], ['Intervalo de cambio sugerido', 'Según análisis']] }),
    p({ id: 'compresor-ss-46', name: 'Lubrax Compresor SS 46', category: 'industrial', sae: 'ISO VG 46', specs: ['DIN 51506 VDL'], base: 'Sintético',
      short: 'Compresores de tornillo con intervalos extendidos.',
      description: 'Aceite sintético para compresores de tornillo y de pistón. Alta resistencia a la oxidación y formación mínima de barnices, permitiendo intervalos de servicio extendidos.',
      presentations: ['20 L', 'Tambo 200 L'],
      applications: ['Compresores de tornillo rotativo', 'Compresores de pistón de doble etapa', 'Salas de compresores de operación continua', 'Plantas con programa de intervalos extendidos'],
      properties: [['Índice de viscosidad', '132'], ['Viscosidad a 40 °C', '46 mm²/s'], ['Punto de inflamación', '252 °C'], ['Demulsibilidad', '40/40/0 (15 min)'], ['Intervalo de cambio sugerido', 'Hasta 8.000 h']] }),
    p({ id: 'tractor-utto-10w-30', name: 'Lubrax Tractor UTTO 10W-30', category: 'agricola', sae: '10W-30', specs: ['UTTO'], base: 'Mineral',
      short: 'Universal para transmisión, hidráulico y frenos húmedos de tractor.',
      description: 'Aceite universal de transmisión y sistema hidráulico para tractores con frenos húmedos y toma de fuerza. Un solo producto para varios circuitos del equipo agrícola.',
      presentations: ['20 L', 'Tambo 200 L'],
      applications: ['Transmisión y sistema hidráulico de tractores', 'Frenos húmedos y toma de fuerza', 'Cosechadoras y equipo de labranza', 'Operación de temporada con largas jornadas'],
      properties: [['Índice de viscosidad', '140'], ['Viscosidad a 100 °C', '11,2 mm²/s'], ['Punto de inflamación', '226 °C'], ['Fricción en frenos húmedos', 'Aprobado'], ['Intervalo de cambio sugerido', 'Hasta 1.200 h']] }),
    p({ id: 'agro-motor-15w-40', name: 'Lubrax Agro Motor 15W-40', category: 'agricola', sae: '15W-40', specs: ['API CJ-4'], base: 'Semisintético',
      short: 'Motor diésel agrícola en ambientes con polvo y alta carga.',
      description: 'Aceite para motores diésel de maquinaria agrícola en operación con carga sostenida y alta exposición a polvo. Control de hollín y protección del tren de válvulas en jornadas largas.',
      presentations: ['20 L', 'Tambo 200 L', 'Granel 1000 L'],
      applications: ['Tractores y cosechadoras diésel', 'Equipo de riego con motor estacionario', 'Operación en ambientes polvorientos', 'Jornadas continuas de temporada'],
      properties: [['Índice de viscosidad', '140'], ['Viscosidad a 100 °C', '14,5 mm²/s'], ['TBN', '9,8 mg KOH/g'], ['Ceniza sulfatada', '1,0 %'], ['Intervalo de cambio sugerido', 'Hasta 500 h']] }),
    p({ id: 'pesada-max-15w-40', name: 'Lubrax Pesada Max 15W-40', category: 'linea-pesada', sae: '15W-40', specs: ['API CK-4', 'ACEA E9'], base: 'Sintético', featured: true,
      short: 'Motor diésel de alto kilometraje en servicio continuo.',
      description: 'Aceite sintético para motores diésel de trabajo pesado en operación continua y altas temperaturas. Alta reserva de detergencia y estabilidad al corte para intervalos extendidos en tractocamión y maquinaria de obra.',
      presentations: ['Cubeta 19 L', 'Tambo 200 L', 'Granel 1000 L'],
      applications: ['Tractocamiones de larga distancia', 'Maquinaria de movimiento de tierra', 'Equipo minero fuera de carretera', 'Flotas con análisis de aceite programado'],
      properties: [['Índice de viscosidad', '146'], ['Viscosidad a 100 °C', '14,9 mm²/s'], ['TBN', '10,4 mg KOH/g'], ['Ceniza sulfatada', '0,9 %'], ['Intervalo de cambio sugerido', 'Según análisis, hasta 60.000 km']] }),
    p({ id: 'hidraulico-hd-68', name: 'Lubrax Hidráulico HD 68', category: 'linea-pesada', sae: 'ISO VG 68', specs: ['DIN 51524-2 HLP'], base: 'Mineral',
      short: 'Sistemas hidráulicos de maquinaria pesada a alta presión.',
      description: 'Fluido hidráulico antidesgaste para excavadoras, retroexcavadoras y grúas que operan a alta presión y con variaciones fuertes de temperatura. Buena filtrabilidad y separación de agua.',
      presentations: ['Cubeta 19 L', 'Tambo 200 L', 'Granel 1000 L'],
      applications: ['Excavadoras y retroexcavadoras', 'Grúas y plataformas elevadoras', 'Sistemas hidráulicos de alta presión', 'Equipo de obra en exteriores'],
      properties: [['Índice de viscosidad', '104'], ['Viscosidad a 40 °C', '68 mm²/s'], ['Punto de escurrimiento', '-24 °C'], ['Prueba FZG', 'Etapa 11'], ['Intervalo de cambio sugerido', '4.000 h o según análisis']] }),
    p({ id: 'trans-hd-80w-90', name: 'Lubrax Trans HD 80W-90', category: 'linea-pesada', sae: '80W-90', specs: ['API GL-5', 'MT-1'], base: 'Mineral',
      short: 'Diferenciales y cajas de camión de carga y volteo.',
      description: 'Aceite de extrema presión para diferenciales, mandos finales y cajas manuales de vehículo pesado. Protege engranajes hipoidales bajo carga sostenida y golpe de arranque.',
      presentations: ['Cubeta 19 L', 'Tambo 200 L'],
      applications: ['Diferenciales de tractocamión', 'Camiones tolva y mixer', 'Mandos finales de maquinaria', 'Cajas manuales de alta carga'],
      properties: [['Índice de viscosidad', '98'], ['Viscosidad a 100 °C', '14,2 mm²/s'], ['Punto de inflamación', '226 °C'], ['Prueba FZG', 'Etapa 12'], ['Intervalo de cambio sugerido', 'Hasta 100.000 km']] })
  ];

  /* Líneas de producto que trabaja cada distribuidor (define disponibilidad) */
  var LINES = {
    automotriz: ['valora-5w-30', 'essencial-20w-50', 'top-turbo-15w-40', 'extra-diesel-15w-40', 'motomax-10w-30', 'atf-multi'],
    pesada: ['top-turbo-15w-40', 'extra-diesel-15w-40', 'pesada-max-15w-40', 'hidraulico-hd-68', 'trans-hd-80w-90', 'gear-85w-140'],
    agricola: ['tractor-utto-10w-30', 'agro-motor-15w-40', 'extra-diesel-15w-40', 'gear-85w-140'],
    industrial: ['hidraulico-hv-68', 'compresor-ss-46', 'ferro-gear-220', 'marine-deck-68'],
    maritima: ['marine-tp-40', 'marine-deck-68', 'hidraulico-hv-68'],
    ferroviaria: ['ferro-loco-40', 'ferro-gear-220', 'gear-85w-140']
  };
  function lines() {
    var out = [];
    for (var i = 0; i < arguments.length; i++) out = out.concat(LINES[arguments[i]]);
    return out.filter(function (v, idx) { return out.indexOf(v) === idx; });
  }

  var distributors = [
    { id: 'zona-santiago-centro', name: 'Lubricantes Centro Santiago', label: 'Zona Santiago Centro', region: 'Metropolitana de Santiago', city: 'Santiago', address: 'Dirección de ejemplo 1250, Santiago', phone: '+56 2 2000 0101', hours: 'Lun a Vie 8:30–18:30 · Sáb 9:00–13:00', web: 'https://example.com', lat: -33.4489, lng: -70.6693, purchase: 'Mayorista y minorista', packs: ['1 L', '4 L', '20 L', 'Tambo 200 L'], products: lines('automotriz', 'pesada') },
    { id: 'zona-quilicura', name: 'Distribuidora Norte Industrial', label: 'Zona Quilicura', region: 'Metropolitana de Santiago', city: 'Quilicura', address: 'Dirección de ejemplo 980, Quilicura', phone: '+56 2 2000 0102', hours: 'Lun a Vie 8:00–17:30', web: 'https://example.com', lat: -33.3597, lng: -70.7277, purchase: 'Solo mayorista', packs: ['Tambo 200 L', 'Granel 1000 L'], products: lines('industrial', 'pesada') },
    { id: 'zona-antofagasta', name: 'Suministros Mineros del Norte', label: 'Zona Antofagasta', region: 'Antofagasta', city: 'Antofagasta', address: 'Dirección de ejemplo 455, Antofagasta', phone: '+56 55 200 0103', hours: 'Lun a Sáb 7:30–18:00', web: 'https://example.com', lat: -23.6509, lng: -70.3975, purchase: 'Solo mayorista', packs: ['Cubeta 19 L', 'Tambo 200 L', 'Granel 1000 L'], products: lines('pesada', 'industrial') },
    { id: 'zona-la-serena', name: 'Lubricentro Elqui', label: 'Zona La Serena', region: 'Coquimbo', city: 'La Serena', address: 'Dirección de ejemplo 312, La Serena', phone: '+56 51 200 0104', hours: 'Lun a Vie 9:00–19:00 · Sáb 9:00–14:00', web: 'https://example.com', lat: -29.9027, lng: -71.2519, purchase: 'Minorista', packs: ['1 L', '4 L', '20 L'], products: lines('automotriz') },
    { id: 'zona-valparaiso', name: 'Lubricantes Puerto Valparaíso', label: 'Zona Valparaíso', region: 'Valparaíso', city: 'Valparaíso', address: 'Dirección de ejemplo 77, Valparaíso', phone: '+56 32 200 0105', hours: 'Lun a Sáb 6:00–18:00', web: 'https://example.com', lat: -33.0472, lng: -71.6127, purchase: 'Mayorista y minorista', packs: ['4 L', 'Tambo 200 L', 'Granel 1000 L'], products: lines('maritima', 'automotriz') },
    { id: 'zona-rancagua', name: 'Agrolubricantes O’Higgins', label: 'Zona Rancagua', region: "Libertador General Bernardo O'Higgins", city: 'Rancagua', address: 'Dirección de ejemplo 640, Rancagua', phone: '+56 72 200 0106', hours: 'Lun a Sáb 7:30–17:30', web: 'https://example.com', lat: -34.1708, lng: -70.7444, purchase: 'Mayorista y minorista', packs: ['20 L', 'Cubeta 19 L', 'Tambo 200 L'], products: lines('agricola', 'automotriz') },
    { id: 'zona-talca', name: 'Lubricantes del Maule', label: 'Zona Talca', region: 'Maule', city: 'Talca', address: 'Dirección de ejemplo 1020, Talca', phone: '+56 71 200 0107', hours: 'Lun a Vie 8:30–18:00 · Sáb 9:00–13:00', web: 'https://example.com', lat: -35.4264, lng: -71.6554, purchase: 'Mayorista y minorista', packs: ['1 L', '4 L', '20 L', 'Tambo 200 L'], products: lines('automotriz', 'agricola') },
    { id: 'zona-concepcion', name: 'Distribuidora Biobío', label: 'Zona Concepción', region: 'Biobío', city: 'Concepción', address: 'Dirección de ejemplo 2100, Concepción', phone: '+56 41 200 0108', hours: 'Lun a Vie 8:00–18:00', web: 'https://example.com', lat: -36.8270, lng: -73.0503, purchase: 'Solo mayorista', packs: ['Cubeta 19 L', 'Tambo 200 L', 'Granel 1000 L'], products: lines('industrial', 'ferroviaria', 'pesada') },
    { id: 'zona-temuco', name: 'Lubricantes Araucanía', label: 'Zona Temuco', region: 'La Araucanía', city: 'Temuco', address: 'Dirección de ejemplo 845, Temuco', phone: '+56 45 200 0109', hours: 'Lun a Sáb 8:00–18:30', web: 'https://example.com', lat: -38.7359, lng: -72.5904, purchase: 'Mayorista y minorista', packs: ['1 L', '4 L', '20 L', 'Tambo 200 L'], products: lines('agricola', 'automotriz') },
    { id: 'zona-puerto-montt', name: 'Marítima Sur Lubricantes', label: 'Zona Puerto Montt', region: 'Los Lagos', city: 'Puerto Montt', address: 'Dirección de ejemplo 33, Puerto Montt', phone: '+56 65 200 0110', hours: 'Lun a Vie 7:00–17:00', web: 'https://example.com', lat: -41.4693, lng: -72.9424, purchase: 'Solo mayorista', packs: ['Tambo 200 L', 'Granel 1000 L'], products: lines('maritima', 'industrial') }
  ];

  /* Disponibilidad inversa: producto → distribuidores */
  products.forEach(function (prod) {
    prod.distributors = distributors.filter(function (d) { return d.products.indexOf(prod.id) > -1; }).map(function (d) { return d.id; });
  });

  var faqs = [
    { q: '¿Qué es un lubricante?', a: 'Es un fluido que permite disminuir la fricción y evitar el desgaste de las piezas de los distintos componentes de un vehículo, como el motor, caja de cambios y transmisión.' },
    { q: '¿Cuáles son las funciones de un lubricante de motor?', a: 'Reduce la fricción y el desgaste, refrigera las piezas internas, mantiene el motor limpio al arrastrar residuos hacia el filtro, protege contra la corrosión y ayuda a sellar entre anillos y cilindros.' },
    { q: '¿Cómo se clasifican los lubricantes?', a: 'Por su base (mineral, semisintética o sintética), por su viscosidad según la norma SAE y por su nivel de desempeño según especificaciones como API o ACEA.' },
    { q: '¿Se pueden mezclar dos marcas de lubricantes?', a: 'Es posible en una emergencia si tienen la misma viscosidad y especificación, pero se recomienda usar un solo producto para mantener el desempeño de sus aditivos.' },
    { q: '¿Cuál es la diferencia entre un aceite mineral y uno sintético?', a: 'El mineral se obtiene de la refinación del petróleo. El sintético se produce mediante procesos químicos que dan moléculas más uniformes, con mejor estabilidad a altas temperaturas y mejor fluidez en frío.' },
    { q: '¿Es normal que un motor consuma aceite?', a: 'Sí, un consumo moderado es normal por el funcionamiento propio del motor. Un consumo elevado puede indicar desgaste o fugas y debe revisarse en un taller.' },
    { q: '¿La calidad del aceite sintético es superior a la del aceite mineral?', a: 'El sintético ofrece mayor protección en condiciones exigentes y permite intervalos de cambio más largos. Lo más importante es usar el aceite que recomienda el fabricante del vehículo.' },
    { q: '¿Cuál es la viscosidad más adecuada para un vehículo?', a: 'La que indica el manual del fabricante, que considera el diseño del motor y las condiciones de uso.' },
    { q: '¿Existen lubricantes diseñados para una cantidad de kilometrajes determinados?', a: 'Sí. Hay aceites formulados para motores de alto kilometraje, que ayudan a controlar el consumo de aceite y proteger sellos y piezas con desgaste.' },
    { q: '¿Cómo se mide correctamente el nivel de aceite del motor?', a: 'Con el vehículo en superficie plana y el motor frío o apagado hace algunos minutos: se retira la varilla, se limpia, se vuelve a introducir y se verifica que el nivel quede entre las marcas de mínimo y máximo.' },
    { q: '¿Por qué es importante revisar el nivel de aceite en un vehículo?', a: 'Un nivel bajo reduce la lubricación y la refrigeración del motor, lo que acelera el desgaste y puede provocar fallas graves.' },
    { q: '¿Por qué es necesario realizar cambio de aceite?', a: 'Con el uso, el aceite se degrada y acumula contaminantes, perdiendo su capacidad de proteger. Cambiarlo a tiempo mantiene el motor limpio y prolonga su vida útil.' }
  ];

  var attentionFaqs = [
    { q: '¿Cuánto tarda la respuesta a un reclamo?', a: 'Confirmamos el caso en 24 horas hábiles y entregamos la resolución en un máximo de 15 días, con reposición o nota de crédito cuando procede.' },
    { q: '¿Qué datos necesito para abrir un caso?', a: 'Producto, número de lote del envase, factura o pedido, y una descripción de lo ocurrido. Con eso asignamos ejecutivo el mismo día.' },
    { q: '¿Puedo comprar directo o debo ir con un distribuidor?', a: 'La venta se hace a través de la red de distribuidores autorizados. Si necesitas volumen o entrega en planta, te asignamos el distribuidor de tu zona.' },
    { q: '¿Cómo doy seguimiento a un caso abierto?', a: 'Con el número de caso puedes escribir al correo de atención o llamar a la línea; el mismo ejecutivo continúa el seguimiento hasta el cierre.' }
  ];

  /* Blog: contenido de ejemplo (lorem ipsum). En el CMS: entradas + taxonomías
     "categoría del blog" y "etiqueta". Imágenes de ejemplo en assets/img/blog/. */
  var postCategories = [
    { id: 'mantenimiento', name: 'Mantenimiento' },
    { id: 'industria', name: 'Lubricación industrial' },
    { id: 'flotas', name: 'Flotas y transporte' },
    { id: 'agro', name: 'Agro y maquinaria' },
    { id: 'normas', name: 'Normas y especificaciones' },
    { id: 'novedades', name: 'Novedades Lubrax' }
  ];
  var postTags = [
    { id: 'aceite-de-motor', name: 'Aceite de motor' },
    { id: 'viscosidad', name: 'Viscosidad' },
    { id: 'normas-api', name: 'Normas API' },
    { id: 'diesel', name: 'Diésel' },
    { id: 'hidraulicos', name: 'Hidráulicos' },
    { id: 'analisis-de-aceite', name: 'Análisis de aceite' },
    { id: 'cambio-de-aceite', name: 'Cambio de aceite' },
    { id: 'motocicletas', name: 'Motocicletas' },
    { id: 'mineria', name: 'Minería' }
  ];
  var LOREM = [
    ['Lorem ipsum dolor sit amet, consectetur adipiscing elit', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.'],
    ['Sed do eiusmod tempor incididunt ut labore et dolore magna', 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores.'],
    ['Ut enim ad minim veniam, quis nostrud exercitation ullamco', 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam.'],
    ['Duis aute irure dolor in reprehenderit in voluptate velit', 'Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur.'],
    ['Excepteur sint occaecat cupidatat non proident', 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti.'],
    ['Curabitur pretium tincidunt lacus, nulla gravida orci', 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat.'],
    ['Nam fermentum nibh at lacus placerat vestibulum', 'Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.'],
    ['Integer posuere erat a ante venenatis dapibus posuere velit', 'Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur.'],
    ['Maecenas faucibus mollis interdum, donec ullamcorper', 'Similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga harum quidem.'],
    ['Aenean lacinia bibendum nulla sed consectetur', 'Et harum quidem rerum facilis est et expedita distinctio, nam libero tempore cum soluta nobis eligendi.'],
    ['Vestibulum id ligula porta felis euismod semper', 'Omnis voluptas assumenda est, omnis dolor repellendus, temporibus autem quibusdam et aut officiis debitis.'],
    ['Cras mattis consectetur purus sit amet fermentum', 'Nulla vitae elit libero, a pharetra augue. Donec sed odio dui, cras justo odio dapibus ac facilisis in egestas.']
  ];
  /* post(n, categoría, etiquetas, fecha, popular) */
  function post(n, category, tags, date, popular) {
    var img = 'assets/img/blog/blog-0' + (((n - 1) % 6) + 1);
    return {
      id: 'articulo-' + (n < 10 ? '0' + n : n), title: LOREM[n - 1][0], excerpt: LOREM[n - 1][1],
      category: category, tags: tags, date: date, popular: !!popular,
      url: 'blogarticle.html', image: img + '-640.webp', imageSet: img + '-640.webp 640w, ' + img + '.webp 1200w'
    };
  }
  var posts = [
    post(1, 'mantenimiento', ['aceite-de-motor', 'cambio-de-aceite'], '2026-10-14', true),
    post(2, 'industria', ['hidraulicos', 'mineria'], '2026-10-02', true),
    post(3, 'normas', ['normas-api', 'viscosidad'], '2026-09-22'),
    post(4, 'flotas', ['diesel', 'analisis-de-aceite'], '2026-09-10', true),
    post(5, 'novedades', ['aceite-de-motor'], '2026-08-28'),
    post(6, 'agro', ['diesel', 'hidraulicos'], '2026-08-15'),
    post(7, 'mantenimiento', ['motocicletas', 'cambio-de-aceite'], '2026-07-30', true),
    post(8, 'industria', ['analisis-de-aceite', 'mineria'], '2026-07-12'),
    post(9, 'normas', ['viscosidad', 'aceite-de-motor'], '2026-06-26'),
    post(10, 'flotas', ['diesel', 'cambio-de-aceite'], '2026-06-08'),
    post(11, 'agro', ['hidraulicos', 'viscosidad'], '2026-05-21'),
    post(12, 'novedades', ['normas-api'], '2026-05-04')
  ];

  window.LBX_MOCK = {
    categories: categories,
    products: products,
    distributors: distributors,
    faqs: faqs,
    attentionFaqs: attentionFaqs,
    postCategories: postCategories,
    postTags: postTags,
    posts: posts
  };
})();
