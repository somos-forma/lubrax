# Lubrax · Sitio web (fase 2)

Maqueta HTML + Bootstrap 5.3 lista para integrarse en un CMS (WordPress o CMS propio).
Está construida sobre la base optimizada de la fase 1 y aplica el diseño de los wireframes de home y productos.

| Página | Archivo | Qué incluye |
|---|---|---|
| Inicio | `index.html` | Slider editable en el HTML, catálogo regional, categorías, buscador (categoría y viscosidad / libre) y planta |
| Catálogo | `productos.html` | Categorías, filtros (base, viscosidad, especificación y combustible), búsqueda, orden, vista cuadrícula o lista, paginación y disponibilidad por zona |
| Detalle | `producto.html?id=…` | Galería, presentaciones, disponibilidad, aplicaciones, propiedades, documentos PDF con visor en modal y distribuidores |
| Distribuidores | `distribuidores.html` | Vista Mapa o Listado, filtros por región, producto y texto, "cerca de mí", perfil ampliado en modal, llamar y elegir distribuidor |
| Blog | `blog.html` | Artículos con filtro por categoría, etiquetas, búsqueda, orden y paginación (mismos componentes que el catálogo) |
| Artículo | `blogarticle.html` | Plantilla de artículo: migas, metadatos, figuras, etiquetas y barra lateral |
| Contacto | `contacto.html` | Canales, servicios y formulario con campos según el tipo de solicitud |
| Quiénes somos | `nosotros.html` | Empresa, cifras, respaldo y preguntas frecuentes con buscador |
| Políticas de privacidad | `politicas.html` | Texto legal con índice lateral (contenido de ejemplo) |
| Términos y condiciones | `terminos.html` | Texto legal con índice lateral (contenido de ejemplo) |
| Error 404 | `404.html` | "Volver atrás", ir al inicio, buscador de productos y enlaces útiles |

---

## 1. Verlo en local

Se puede abrir directamente con doble clic. Aun así, se recomienda usar un servidor local para ver todo, incluido el mapa base:

```bash
cd lubrax
python3 -m http.server 8080      # luego abrir http://localhost:8080
```

Al abrir con `file://`, OpenStreetMap bloquea el mapa base porque exige el encabezado *Referer*. Por eso la página no lo pide y muestra un aviso. Los marcadores, los filtros y el listado siguen funcionando igual.

El visor de PDF también funciona sin servidor en el escritorio, porque usa el lector de PDF del propio navegador. Lo único que cambia en local es el botón "Descargar": el atributo `download` solo fuerza la descarga cuando el sitio está en un servidor, así que con `file://` el navegador puede abrir el PDF en vez de descargarlo.

---

## 2. Estructura

```
lubrax/
├── index.html, productos.html, producto.html, distribuidores.html, contacto.html, nosotros.html
├── blog.html, blogarticle.html, politicas.html, terminos.html, 404.html
├── robots.txt · sitemap.xml · site.webmanifest · favicon.ico
└── assets/
    ├── css/main.css            estilos propios (índice de 23 secciones al inicio del archivo)
    ├── fonts/                  Saira y Archivo variables, subconjunto latino (woff2)
    ├── img/                    marca, íconos de categorías (SVG), hero, home, páginas, blog, OG
    ├── js/                     JavaScript de PRODUCCIÓN (solo depende del DOM)
    │   ├── app.js              núcleo: zona activa, header, animaciones, formularios, FAQ,
    │   │                       paginación compartida, índice legal y "volver atrás"
    │   ├── slider.js           slider del home
    │   ├── finder.js           buscador del home (categoría y viscosidad)
    │   ├── catalog.js          filtros y paginación del catálogo
    │   ├── product.js          detalle de producto
    │   ├── locator.js          mapa y listado de distribuidores
    │   ├── blog.js             filtros, orden y paginación del blog
    │   └── contact.js          formulario de contacto
    └── mock/                   ⚠ CONTENIDO DE PRUEBA, se elimina al conectar el CMS
        ├── mock-data.js        productos, categorías, distribuidores, FAQ, artículos del blog
        ├── mock-render.js      rellena las plantillas <template> con esos datos
        ├── img/                envases de ejemplo
        └── docs/               PDF de ejemplo (ficha técnica y hoja de seguridad)
```

---

## 3. Cómo funciona el contenido de prueba (y cómo quitarlo)

El JavaScript de producción (`assets/js/`) **nunca lee el mock**. Trabaja solo con el marcado y sus atributos `data-*`, como si el HTML viniera del servidor.

Lo que **no** es parte del mock y se edita a mano en el HTML:
- el slider del home (`index.html`);
- el cuerpo del artículo (`blogarticle.html`), que es la plantilla de un artículo;
- los textos legales (`politicas.html`, `terminos.html`) y la página 404.

Cada página trae, al final del `<body>`, plantillas `<template id="tpl-…">`. Esas plantillas son el **contrato de marcado** para el desarrollador del CMS. Hoy, `mock-render.js` las rellena con datos de prueba y las inserta en los contenedores marcados con `data-mock="…"`.

Orden de los scripts (todos con `defer`, se ejecutan en este orden):

```
bootstrap.bundle → mock-data → mock-render → app.js → script de la página
```

**Para pasar a producción:**

1. Borrar la carpeta `assets/mock/` completa.
2. En cada página, quitar el bloque `<!-- MOCK --> … <!-- /MOCK -->` (dos `<script>`).
3. Imprimir desde el CMS, dentro de cada contenedor `data-mock`, el mismo HTML de su plantilla `tpl-…`. Después se pueden borrar las plantillas y los atributos `data-mock`.
4. Quitar `Disallow: /assets/mock/` de `robots.txt`.

Sintaxis de las plantillas: `{{campo}}` es texto escapado y `{{{campo}}}` es un fragmento HTML. Las filas de tablas se cargan en un `<tbody data-slot="…">`, porque un `<template>` no admite texto suelto dentro de una tabla.

---

## 4. Contratos de marcado (lo que debe imprimir el CMS)

### Zona activa del header: distribuidor o región (todas las páginas)

- El modal `#distributorModal` contiene un `<select id="distributorSelect">` con un `<option>` por distribuidor:

  ```html
  <option value="zona-talca" data-label="Zona Talca" data-region="Maule" data-lat="-35.4264" data-lng="-71.6554">Lubricantes del Maule</option>
  ```

- El selector `#distributorRegion` se arma solo con las regiones de esas opciones. Al elegir una región, la primera opción del distribuidor pasa a ser "Todos los distribuidores de {región}".
- Hay tres estados posibles. Todos se mantienen al navegar y al recargar:

  | Estado | Cómo se elige | Header | `localStorage` |
  |---|---|---|---|
  | Distribuidor | Región + distribuidor | "Distribuidor · Zona Talca" | `lbx.distributor` |
  | Región completa | Solo región | "Región · Maule" | `lbx.region` |
  | Todos | "Ver todos" | "Distribuidor · Todos" | (vacío) |

- La zona elegida se aplica en todo el sitio:
  - el catálogo muestra lo disponible en esa zona ("Solo productos disponibles en esta región" o "… de este distribuidor");
  - el detalle indica en cuántos distribuidores de la región está el producto y marca los de la zona;
  - el localizador abre con esa región filtrada;
  - el formulario de contacto precarga la región.
- Al cambiar se emite `lbx:distributorchange` (`detail` = alcance) y se actualizan:
  - `[data-dist-label]` ("Distribuidor" o "Región");
  - `[data-dist-name]` (el `data-label` del distribuidor, o la región);
  - `[data-dist-fullname]`;
  - los atributos `html[data-distributor]` y `html[data-region]`.
- API pública:
  - `LBX.distributor.scope()` devuelve `{ type: 'distributor' | 'region' | 'all', ids, region, label, name }`. `ids` son los distribuidores que cuentan.
  - `.get()` devuelve el distribuidor o `null`; `.region()` devuelve la región o `''`.
  - `.set(id)`, `.setRegion(nombre)` y `.clear()` cambian la zona; `.list()` lista los distribuidores.

### Paginación compartida (catálogo y blog)

- `LBX.pagination(nav, { page, pages, onChange })` dibuja el paginador dentro de un `<nav>`: anterior, números y siguiente.
- Con más de 7 páginas se acorta con "…" (por ejemplo, `1 … 4 5 6 … 12`). Con una sola página, el `<nav>` queda vacío.
- Si el CMS pagina en el servidor, debe imprimir el mismo marcado con enlaces:

  ```html
  <nav aria-label="Paginación">
    <ul class="pagination justify-content-center flex-wrap">
      <li class="page-item"><a class="page-link" href="?pagina=1" aria-label="Página anterior">‹</a></li>
      <li class="page-item active"><a class="page-link" href="?pagina=2" aria-current="page">2</a></li>
      …
    </ul>
  </nav>
  ```

### Catálogo (`productos.html`)

- Un `<li>` por producto dentro de `#productGrid` (ver la plantilla `tpl-product-card`). Atributos clave del `<article>`:
  - `data-product`, `data-id`, `data-name`, `data-category`, `data-category-name`;
  - `data-fuel`, `data-base`, `data-sae`;
  - `data-specs="API SP|ILSAC GF-6A"` (separadas con `|`);
  - `data-distributors="zona-talca zona-temuco"` (separados por espacio);
  - `data-featured="1"`.
- Los grupos de filtros (base, viscosidad, especificación y combustible) se **construyen solos** a partir de esos atributos.
- Las categorías van como `<a data-cat="automotriz" data-name="Automotriz">… <span class="count"></span></a>`.
- La URL refleja el estado. Parámetros:
  - `categoria`, `combustible`, `base`, `sae`, `espec`, `q`;
  - `orden`, `pagina`, y `disponibles=0` para ver también lo que no está en la zona elegida.
- Hay 9 productos por página (`PAGE_SIZE` en `catalog.js`). Con muchos productos, conviene paginar en el servidor y mantener los mismos parámetros.

### Detalle (`producto.html`)

- Plantilla `tpl-product-page`. El contenedor `[data-product-page]` lleva `data-id` y `data-distributors`.
- `#pdpMainImage` es la imagen principal. Las miniaturas son `[data-gallery-src]`.
- Cada presentación es un botón `[data-pres][data-pres-image]`; al elegirla, cambia la imagen.
- `[data-avail-box]` muestra la disponibilidad según la zona del header:
  - con un distribuidor, si lo tiene o no;
  - con una región, en cuántos distribuidores de esa región está;
  - si no está, ofrece ir a `distribuidores.html?producto=id` (con `&region=` cuando aplica).
- Las tarjetas de distribuidores `[data-mini-dist="id"]` de la zona elegida reciben la clase `.is-mine`.
- **Documentos PDF:** se muestran como tarjetas con miniatura de la primera página, tipo, peso y fecha, y dos acciones:
  - **Ver** abre el visor en un modal (ver más abajo);
  - **Descargar** usa el atributo `download`.
- Recomendación para el CMS: URL amigable (`/productos/valora-5w-30/`) en vez de `?id=`, e imprimir el JSON-LD `Product` y `BreadcrumbList` en el servidor. Hoy los agrega el mock.

### Visor de PDF (detalle de producto)

- Cualquier enlace con `data-pdf-view` abre el modal `#pdfModal` (lo maneja `app.js`):

  ```html
  <a href="ficha.pdf" target="_blank" rel="noopener" data-pdf-view data-pdf-title="Ficha técnica"
     data-pdf-meta="PDF · 216 KB · Actualizado Septiembre 2026" data-pdf-thumb="ficha.webp" data-pdf-product="Lubrax Valora 5W-30">Ver</a>
  ```

- **Escritorio:** muestra el PDF con el lector del navegador dentro de un `<iframe>`, con los botones "Descargar" y "Abrir en una pestaña nueva".
- **Teléfonos** (Android no muestra PDF dentro de una página; iOS solo muestra la primera hoja) **y navegadores configurados para descargar los PDF:** el modal muestra la miniatura y los botones "Abrir PDF" y "Descargar".
- Sin JavaScript, o con Ctrl/Cmd + clic, el enlace abre el PDF en una pestaña nueva.
- Si más adelante se quiere ver el PDF dentro de la página también en el teléfono, se puede cambiar el `<iframe>` por PDF.js. Eso requiere que el sitio esté en un servidor.

### Distribuidores (`distribuidores.html`)

- Un `<li>` por distribuidor dentro de `#distList` (plantilla `tpl-dist-card`):
  - `<article data-distributor data-id data-name data-label data-region data-city data-lat data-lng data-products="id1 id2">`.
  - Los datos del perfil van marcados con `data-field`: `purchase`, `label`, `address`, `hours`, `phone`, `packs`, `route` y `web`.
- Las regiones del filtro se construyen desde las tarjetas. Si en el header hay una región o un distribuidor elegido, el filtro de región parte con esa región (un `?region=` en la URL tiene prioridad).
- El selector `#locProduct` lleva los productos agrupados por categoría:

  ```html
  <optgroup label="Automotriz">
    <option value="valora-5w-30" data-url="/productos/valora-5w-30/">Lubrax Valora 5W-30</option>
  </optgroup>
  ```

  De ahí salen los nombres, las categorías y los enlaces de los productos en las tarjetas y en el perfil. Sin `data-url`, el enlace es `producto.html?id=…`.
- Botones de cada tarjeta:
  - `[data-action="profile"]`: abre el perfil ampliado (también al hacer clic en el nombre);
  - `[data-action="select"]`: elegir como mi distribuidor;
  - `[data-action="focus"]`: ver en el mapa (desde "Listado" cambia a la vista de mapa).
- Íconos de cada tarjeta, en este orden: ver en el mapa, ver ruta, **llamar** (`href="tel:…"`) e ir al sitio web. Todos tienen tooltip de Bootstrap (`data-bs-toggle="tooltip" data-bs-title="…"`) y un `aria-label` con el nombre del distribuidor. `app.js` activa los tooltips en todas las páginas.
- **Vistas:** el selector "Vista" alterna `data-view="map"` (listado lateral + mapa; en el teléfono, solo mapa) y `data-view="list"` (tarjetas en cuadrícula con una muestra de productos).
  - Por defecto: Mapa en escritorio y Listado en el teléfono.
  - La elección del usuario se recuerda en `localStorage` (`lbx.locView`).
- **Perfil ampliado:** el modal `#distProfile` se completa con los datos de la tarjeta. Muestra:
  - productos agrupados por categoría y enlazados a su ficha;
  - dirección, horario, teléfono, envases y sitio web (se muestra el dominio; la fila se oculta si no hay sitio);
  - acciones: "Elegir distribuidor", "Ver ruta", "Sitio web" y "Ver en el mapa".
  - En el teléfono se abre a pantalla completa. El globo de cada marcador del mapa también tiene "Ver perfil".
- **Parámetros de URL:** `?producto=id`, `?region=…`, `?vista=mapa|listado` y `?perfil=id` (abre el perfil al cargar, útil para compartir).
- Mapa: Leaflet 1.9.4 con teselas de OpenStreetMap y `referrerPolicy`. Para otro proveedor, cambiar `TILE_URL` y `TILE_OPTIONS` en `locator.js` (ver pendientes).

### Blog (`blog.html`)

- Un `<li>` por artículo dentro de `#blogGrid` (plantilla `tpl-post-card`). Atributos del `<article>`:

  ```html
  <article class="post-card" data-post data-id="…" data-title="…" data-category="mantenimiento"
           data-category-name="Mantenimiento" data-tags="viscosidad aceite-de-motor" data-date="2026-10-14">
  ```

- Los chips de categoría (`[data-blog-categories]`) se **construyen solos** desde las tarjetas, con su conteo. Se elige una categoría a la vez.
- Las etiquetas del costado son enlaces normales que funcionan sin JavaScript. Con JavaScript, filtran sin recargar:

  ```html
  <a href="blog.html?etiqueta=viscosidad" data-tag="viscosidad">#Viscosidad</a>
  ```

- Usa los mismos componentes que el catálogo:
  - la barra de título y conteo (`[data-blog-heading]`, `[data-blog-count]`);
  - la búsqueda `#blogSearch` y el orden `#blogSort` (recientes, antiguos, título);
  - los filtros activos `[data-active-filters]`;
  - el mensaje sin resultados `[data-blog-empty]`, con `[data-blog-reset]`;
  - el paginador `[data-blog-pagination]`.
- La URL refleja el estado: `categoria`, `etiqueta`, `q`, `orden` y `pagina`.
- 6 artículos por página (`PAGE_SIZE` en `blog.js`). Con muchos artículos, conviene paginar en el servidor con los mismos parámetros (ver "Paginación compartida").
- Barra lateral: "Artículos populares" (`tpl-popular`) y etiquetas (`tpl-post-tag`).
- Hoy el mock carga 12 artículos de ejemplo en *lorem ipsum*. Sus imágenes (`assets/img/blog/`, 1200 × 675 y 640 × 360) son recortes de fotos del propio proyecto, para reemplazar.

### Artículo (`blogarticle.html`)

- Es la plantilla de un artículo:
  - migas de pan (Inicio / Blog / categoría / artículo);
  - título `h1`, bajada y metadatos (autor, fecha, tiempo de lectura, categoría);
  - imagen principal, cuerpo con subtítulos `h2` (y `h3` dentro de ellos) y figuras `figure.entry-figure`;
  - etiquetas y "Volver al blog".
- La barra lateral (populares y etiquetas) usa las mismas plantillas del blog.
- El CMS debe imprimir en el servidor el JSON-LD `BlogPosting` y las metaetiquetas `article:*` de cada artículo. Hoy están escritas con datos de ejemplo.

### Páginas legales (`politicas.html`, `terminos.html`)

- Estructura: encabezado compacto, fecha "Última actualización", índice lateral y secciones numeradas `<section id="seccion-N">`. La sección final es `#contacto-legal`.
- El índice `<nav class="legal-toc" data-legal-toc>` (dentro de un `<details>`):
  - resalta la sección visible al hacer scroll;
  - en el teléfono empieza plegado y se pliega al elegir una sección.
- Componentes disponibles: listas con check (`ul.legal-checks`) y nota destacada (`.legal-note`).
- El texto es *lorem ipsum*: el cliente debe entregar los textos legales definitivos.

### Página 404 (`404.html`)

- "Volver atrás" (`<a href="index.html" data-back>`) regresa a la página anterior si venía del mismo sitio. Si se llegó desde otro sitio o escribiendo la URL, lleva al inicio.
- También incluye un buscador de productos y enlaces útiles. Lleva `noindex` y no está en el sitemap.
- **En el servidor:** el 404 se muestra en cualquier ruta (por ejemplo `/productos/no-existe/`). Por eso la página agrega `<base href="/">` cuando no se abre como archivo local, así sus rutas relativas siempre apuntan a la raíz. Si el sitio se publica en una subcarpeta, cambia `/` por esa ruta.
- Configurar el servidor para que responda esta página con estado 404:
  - Apache: `ErrorDocument 404 /404.html`;
  - Nginx: `error_page 404 /404.html;`;
  - en WordPress va en `404.php` del tema.

### Buscador del home (`index.html`)

- Pestañas "Por categoría y viscosidad" (activa por defecto) y "Búsqueda libre".
- Usa una "isla" JSON que imprime el CMS:

  ```html
  <script type="application/json" id="lbx-product-index">[{ "id": "…", "category": "automotriz", "sae": "5W-30" }]</script>
  ```

  Con ella, la lista de viscosidades se ajusta a la categoría y el botón muestra cuántos productos coinciden.
- Sin la isla, ambos formularios siguen funcionando (envío GET a `productos.html`).

### Slider del home (editable en `index.html`)

- Cada diapositiva es un `<article class="hero-slide">` dentro de `.hero__track`. Para agregar una, duplica un `<article>` completo y cambia textos, enlace e imagen.
- Solo la primera lleva la clase `is-active` y su imagen con `fetchpriority="high"`. Las demás llevan `loading="lazy"`.
- Variante con envase recortado (imagen con transparencia): agrega la clase `hero-slide--product`.
- El contador ("01 —— 02"), las flechas y las etiquetas accesibles ("1 de 3") se ajustan solos a la cantidad de diapositivas.
- Intervalo: `data-interval` en la `<section class="hero">`, en milisegundos.
- Si cambias la imagen de la primera diapositiva, actualiza también el `<link rel="preload" as="image">` del `<head>`.
- En el teléfono, la imagen ocupa al menos el 60 % del alto de la pantalla (mínimo 360 px) y el texto queda debajo, con un fundido.

### Formularios

- Los formularios con `.needs-validation` usan la validación de Bootstrap.
- Si el formulario es válido, se emite `lbx:formsubmit` (cancelable, `detail: { form, data }`). Si nadie lo cancela, se envía al `action`.
- El mock lo cancela para mostrar el mensaje de éxito `[data-form-success]` (contacto) o un aviso (newsletter).
- **Contacto:** los campos que dependen del tipo de solicitud van en `<fieldset data-show-for="tipo1 tipo2" hidden disabled>`. Un fieldset deshabilitado no se valida ni se envía, así que sus campos pueden ser `required`.
- Parámetros de URL: `contacto.html?tipo=distribuidor&producto=id#formulario` preselecciona el tipo y el producto.

### Preguntas frecuentes

- Acordeón de Bootstrap (plantilla `tpl-faq`). El buscador se conecta con `data-faq-search="#faqList"`.
- El CMS debe imprimir también el JSON-LD `FAQPage`.

### Animaciones con scroll (reutilizables en cualquier página)

| Atributo | Efecto |
|---|---|
| `data-reveal="up · down · left · right · zoom · clip · title"` | El elemento entra al aparecer en pantalla |
| `data-reveal-delay="0.2"` | Retraso en segundos |
| `data-reveal-stagger="0.07"` (en el padre) | Escalona la entrada de los hijos |
| `data-reveal="title"` + `<span class="line"><span>…</span></span>` | Título que entra por líneas |
| `data-parallax="0.12"` | Desplazamiento suave con el scroll |
| `data-count-to="180" data-count-prefix="+"` | Contador animado |

- Sin JavaScript, o con "reducir movimiento" activado, todo se muestra sin animar.
- Para contenido cargado después (AJAX), llamar a `LBX.reveal(contenedor)`.
- No pongas `data-reveal` en un elemento que ya se mueve con `:hover`. Ponlo en su contenedor (por ejemplo, el `<li>` de una tarjeta).

### Header, menú y footer

- Son iguales en todas las páginas y salen de `index.html`. Si se cambian, hay que copiarlos en el resto (en el CMS, conviene que sean un parcial único).
- La página actual se marca con `aria-current="page"` en el menú. El detalle de producto marca "Productos" y el artículo marca "Blog".

---

## 5. SEO, rendimiento y accesibilidad

**SEO**
- `title`, `description`, `canonical`, Open Graph y Twitter Card en cada página (el 404 no lleva canonical y es `noindex`).
- JSON-LD:
  - `Organization` (con dirección, teléfono y `contactPoint`) y `WebSite` con `SearchAction`;
  - `BreadcrumbList`, `CollectionPage`, `ContactPage`, `AboutPage` y `WebPage` (páginas legales);
  - `Blog` en el listado y `BlogPosting` en el artículo (con `og:type="article"` y `article:*`);
  - `Product` y `FAQPage`, que hoy agrega el mock.
- `sitemap.xml` con todas las páginas públicas, `lastmod`, `changefreq` y `priority`. El CMS debe generarlo con una URL por producto y por artículo.
- `robots.txt` bloquea `/assets/mock/` y apunta al sitemap.

**Rendimiento**
- Fuentes variables autoalojadas, con subconjunto latino y precarga.
- Imágenes WebP con `srcset`, `width` y `height` (evitan saltos de diseño) y `loading="lazy"` bajo el pliegue.
- Precarga de la imagen principal del slider.
- Scripts con `defer`. Cero dependencias además de Bootstrap y Leaflet (este último solo en distribuidores).
- Íconos en un sprite SVG en cada página (sin fuentes de íconos).

**Accesibilidad**
- Enlace "Saltar al contenido" y foco visible.
- Slider con pausa, `inert` en las diapositivas ocultas y control con teclado y gestos.
- Etiquetas en todos los campos, mensajes de error y `aria-live` en los resultados.
- Respeta `prefers-reduced-motion`.
- Verificado:
  - sin desbordes horizontales entre 360 y 1920 px;
  - sin errores de consola;
  - sin IDs duplicados ni referencias ARIA rotas;
  - orden de títulos correcto y sin enlaces vacíos.

---

## 6. Pendientes y datos a validar con el cliente

- [ ] **Datos de contacto:** teléfono `800 363 776`, WhatsApp `+569 3917 1917`, `atencion@lubrax.com` y la dirección de Las Condes vienen del `index.html` del cliente. Se cambian en el header, el menú, el footer, la página de contacto y el JSON-LD `Organization`.
- [ ] **Dominio:** las URLs absolutas (canonical, OG, JSON-LD, sitemap) usan `https://www.lubrax.cl/`.
- [ ] **Redes sociales:** los enlaces apuntan a la portada de cada red.
- [ ] **Contenido de prueba:**
  - distribuidores (nombres, direcciones, teléfonos, coordenadas);
  - valores técnicos de los productos;
  - envases genéricos;
  - PDF de ejemplo;
  - artículos del blog e imágenes;
  - textos legales (políticas y términos).
- [ ] **Endpoints:** el formulario de contacto y el newsletter tienen `action="#"`.
- [ ] **Mapa en producción:** con tráfico alto, conviene un proveedor de teselas con clave (MapTiler, Stadia, Mapbox), porque la política de uso de `tile.openstreetmap.org` limita el uso intensivo.
- [ ] **SRI:** los hashes `integrity` de Bootstrap 5.3.3 y Leaflet 1.9.4 son los publicados oficialmente. Conviene confirmarlos al publicar; si el CDN no coincide, el navegador bloquea el archivo.
- [ ] **Texto "Tambo 200 L":** viene del wireframe. Confirmar si se usa "Tambor".

---

## 7. Historial

**Versión 3**
- **Zona del header:** se puede elegir una región completa además de un distribuidor. La región queda activa al navegar y al recargar, y la siguen el catálogo, el detalle, el localizador y el contacto.
- **Blog:**
  - las tarjetas salen del mock con *lorem ipsum* e imágenes de ejemplo;
  - filtro por categoría (chips con conteo), etiquetas, búsqueda y orden, con los mismos componentes del catálogo;
  - el paginador es el mismo del catálogo (`LBX.pagination`, ahora compartido);
  - el artículo se rehízo con la línea gráfica de Lubrax.
- **Páginas nuevas:** términos y condiciones (enlazada en el footer) y página 404 con "Volver atrás".
- **Políticas:** textos en *lorem ipsum*, sin rastros de la empresa de origen (colores, fuente de íconos, AOS e imágenes externas). El índice ahora apunta a anclas válidas y resalta la sección visible.
- **Metadatos** de blog, artículo, políticas, términos y 404: Open Graph, Twitter Card y JSON-LD acordes a Lubrax.
- **Home:**
  - se quitó la pestaña "Por vehículo" del buscador, con su isla de datos y su JavaScript (`finder.js` y `catalog.js` ya no usan `ids` ni `vehiculo`);
  - en el teléfono, el slider muestra la imagen grande (al menos 60 % del alto) con el texto debajo;
  - las flechas del slider vuelven a verse al pasar el mouse.
- **Distribuidores:** botón de ícono "Llamar" en cada tarjeta, junto a ver en el mapa, ver ruta y sitio web.
- Header, menú y footer del `index.html` del cliente copiados en todas las páginas. También se actualizaron los canales de `contacto.html` y el JSON-LD `Organization`.
- El enlace del teléfono del footer ahora es `tel:800363776`.
- `main.css`:
  - reordenado en 23 secciones, con el índice actualizado;
  - los módulos nuevos (blog, legales, 404) usan los tokens de Lubrax.
- La regla `.modal-dialog { max-width: 90% }` del cliente se limitó a los modales que no son de pantalla completa, porque achicaba el visor de PDF y el perfil en el teléfono.
- `sitemap.xml` actualizado con las páginas nuevas.

**Versión 2**
- El slider del home pasó del mock al HTML de `index.html`, para editarlo a mano.
- Distribuidores:
  - tooltips en los íconos ("Ver en el mapa", "Ver ruta", "Ir al sitio web");
  - perfil ampliado en un modal;
  - selector de vista Mapa / Listado en todos los tamaños.
- Detalle de producto:
  - "Ver" abre el PDF en un modal con opción de descarga;
  - se quitó el carrusel de productos relacionados (con su JavaScript y CSS).
- El footer corregido en `index.html` se copió en todas las páginas.
- Se conservaron los cambios de diseño del cliente en `main.css`, `index.html` y `nosotros.html`.
- Se corrigió el `font-weight` del acordeón de preguntas frecuentes, que tenía dos puntos de ancho completo (`：`) y se ignoraba.
- Las imágenes nuevas (motor y envase oscuro) se redujeron a WebP de 1600 px con versión de 768 px para móvil. Pasaron de 1,6 MB a 200 KB, sin cambio visible.
